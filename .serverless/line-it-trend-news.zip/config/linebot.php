<?php
return [

    'channel_access_token' => getenv('LINE_CHANNEL_ACCESS_TOKEN', null),

    'channel_secret' => getenv('LINE_CHANNEL_SECRET', null),
    
];